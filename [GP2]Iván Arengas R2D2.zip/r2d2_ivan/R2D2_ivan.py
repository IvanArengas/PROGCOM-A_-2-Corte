import pygame
import sys
from pygame.locals import *

pygame.init()
size = width, height = 600, 600
ventana = pygame.display.set_mode(size)

fuente = pygame.font.SysFont("Arial", 30)
texto = fuente.render("Utiliza las flechas para moverlo", 0, (0, 40, 60))

pygame.mixer.init()
sonido = pygame.mixer.Sound("sonido.wav")
pygame.mixer.Sound.play(sonido, -1)

r2d2 = pygame.image.load("rrd2.png")
IMAGE_SIZE = (70, 85)
r2d2 = pygame.transform.scale(r2d2, IMAGE_SIZE)
X = 300
Y = 200

vel = 20
Blanco = (255, 255, 255)

while True:
    ventana.fill(Blanco)
    ventana.blit(r2d2, (X, Y))

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == K_LEFT:
                X -= vel
            elif event.key == K_RIGHT:
                X += vel
            elif event.key == K_UP:
                Y -= vel
            elif event.key == K_DOWN:
                Y += vel

    ventana.blit(texto, (0, 0))
    pygame.display.update()